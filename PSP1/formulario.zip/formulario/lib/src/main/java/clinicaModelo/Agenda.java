/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinicaModelo;

import clinicaControl.Persona;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Wendy RS
 */
public class Agenda {
    Vector vector= new Vector();
    Persona persona = new Persona();
    
    public void GuardarPersona(Persona persona){
    if(vector.add(persona)){
    JOptionPane.showMessageDialog(null, "Se ha agregado correctamente a la persona");
      }
    }
    
    public String MostrarAgenda(){
    String Linea = "", Linea2;
    for(int x=0; x<vector.size();x++){
    persona=(Persona)vector.get(x);
    Linea2 = persona.nombre+" - "+persona.expediente+" - "+persona.apellidos+" - "+persona.edad+" - "+persona.sexo+" - "+persona.direccion+" - "+persona.fechanacimiento+" - "+persona.seguro+" - "+persona.telefono+" - "+persona.email;
    
    Linea=Linea+Linea2+"\n";
    }
    return Linea;
       
    }
}
