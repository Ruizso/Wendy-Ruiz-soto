/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinicaControl;

/**
 *
 * @author Wendy RS
 */
public class Persona {
    public String nombre;
    public String expediente;
    public String apellidos;
    public String edad;
    public String sexo;
    public String direccion;
    public String fechanacimiento;
    public String seguro;
    public String telefono;
    public String email;

    public Persona() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", expediente=" + expediente + ", apellidos=" + apellidos + ", edad=" + edad + ", sexo=" + sexo + ", direccion=" + direccion + ", fechanacimiento=" + fechanacimiento + ", seguro=" + seguro + ", telefono=" + telefono + ", email=" + email + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getExpediente() {
        return expediente;
    }

    public void setExpediente(String expediente) {
        this.expediente = expediente;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(String fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public String getSeguro() {
        return seguro;
    }

    public void setSeguro(String seguro) {
        this.seguro = seguro;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Persona(String nombre, String expediente, String apellidos, String edad, String sexo, String direccion, String fechanacimiento, String seguro, String telefono, String email) {
        this.nombre = nombre;
        this.expediente = expediente;
        this.apellidos = apellidos;
        this.edad = edad;
        this.sexo = sexo;
        this.direccion = direccion;
        this.fechanacimiento = fechanacimiento;
        this.seguro = seguro;
        this.telefono = telefono;
        this.email = email;
    }
    
}
