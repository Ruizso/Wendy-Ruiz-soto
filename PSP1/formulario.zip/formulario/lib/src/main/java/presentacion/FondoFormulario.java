/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacion;

/**
 *
 * @author Wendy RS
 */
import java.awt.Graphics;
import javax.swing.ImageIcon;
public class FondoFormulario extends javax.swing.JPanel {
public FondoFormulario(){
this.setSize(395, 493);
}
@ Override
public void paintComponent(Graphics g){
ImageIcon imagenFondo = new ImageIcon(getClass().getResource("/Presentacion/Imagenes/FondoFormulario.png" ) ) ;

g.drawImage(imagenFondo.getImage(),0,0,395, 493, null);
setOpaque(false);
super.paintComponent(g);
}

}

